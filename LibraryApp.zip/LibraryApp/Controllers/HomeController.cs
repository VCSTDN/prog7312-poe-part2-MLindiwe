﻿using LibraryApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryApp.Controllers
{
    public class HomeController : Controller
    {
        private static Dictionary<string, string> CallNumbers = new Dictionary<string, string>
        {
            { "000", "General Knowledge, Computer Science, Information & General Works" },
            { "100", "Philosophy & Psychology" },
            { "200", "Religion" },
            { "300", "Social Sciences" },
            // Add more call numbers and descriptions as needed
        };

        private static Random random = new Random();

        private static List<string> GetRandomCallNumbers(int count)
        {
            var callNumbers = new List<string>(CallNumbers.Keys);
            var randomCallNumbers = new List<string>();

            for (int i = 0; i < count; i++)
            {
                int index = random.Next(callNumbers.Count);
                randomCallNumbers.Add(callNumbers[index]);
                callNumbers.RemoveAt(index);
            }

            return randomCallNumbers;
        }

        public IActionResult Index()
        {
            // Display the menu options to the user
            return View();
        }

        public IActionResult ReplaceBooks()
        {
            // Generate 10 different call numbers
            List<string> callNumbers = GenerateCallNumbers(10);

            // Pass the call numbers to the view
            return View(callNumbers);
        }

         public IActionResult IdentifyAreas()
         {
            var randomCallNumbers = GetRandomCallNumbers(4);
            var randomDescriptions = new List<string>(CallNumbers.Values);

            if (randomCallNumbers.Count == 0 || randomDescriptions.Count == 0)
            {
                // Handle the situation when the randomCallNumbers or randomDescriptions list is empty
                ViewData["Error"] = "Failed to load data";
                return View();
            }

            randomDescriptions.Remove(CallNumbers[randomCallNumbers[0]]);

            randomDescriptions.Shuffle();
            randomDescriptions.Insert(random.Next(0, 3), CallNumbers[randomCallNumbers[0]]);

            var model = new Dictionary<string, string>();

            for (int i = 0; i < randomCallNumbers.Count; i++)
            {
                model[randomCallNumbers[i]] = randomDescriptions[i];
            }

            return View(model);

         }


        [HttpPost]
        public IActionResult CheckAnswer(string callNumber, string description)
        {
            if (callNumber != null && description != null &&
                CallNumbers.ContainsKey(callNumber) && CallNumbers[callNumber] == description)
            {
                ViewData["Correct"] = true;
                ViewData["CorrectCount"] = (int)(ViewData["CorrectCount"] ?? 0) + 1;
            }
            else
            {
                ViewData["Correct"] = false;
            }
            ViewData["TotalCount"] = (int)(ViewData["TotalCount"] ?? 0) + 1;

            return View();
        }







        private List<string> GenerateCallNumbers(int count)
        {
            List<string> callNumbers = new List<string>();

            Random random = new Random();

            for (int i = 0; i < count; i++)
            {
                // Generate a random topic number between 0 and 999
                int topicNumber = random.Next(1000);

                // Generate a random author's surname (3 uppercase letters)
                string surname = "";
                for (int j = 0; j < 3; j++)
                {
                    char letter = (char)random.Next('A', 'Z' + 1);
                    surname += letter;
                }
                string callNumber = $"{topicNumber:D3}.{surname}";

                callNumbers.Add(callNumber);
            }

            return callNumbers;
      
        }

        public void Reorder()
        {
            

        }


    }
}
