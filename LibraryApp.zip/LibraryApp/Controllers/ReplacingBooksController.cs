﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryApp.Controllers
{
    public class ReplacingBooksController : Controller
    {
        // ...

        public IActionResult ReorderCallNumbers(List<string> callNumbers)
        {
                // Calculate progress percentage
                decimal progressPercentage = ((decimal)callNumbers.Count / 10) * 100;
                ViewBag.ProgressPercentage = progressPercentage.ToString("0");

                // Check user's input for ascending order
                bool isAscendingOrder = true;
                for (int i = 1; i < callNumbers.Count; i++)
                {
                    if (string.Compare(callNumbers[i - 1], callNumbers[i]) > 0)
                    {
                        isAscendingOrder = false;
                        break;
                    }
                }

                if (isAscendingOrder)
                {
                    // User's input is in ascending order
                    // Return a success message or redirect to a success page
                    return View("Success");
                }
                else
                {
                    // User's input is not in ascending order
                    // Return an error message or redirect to an error page
                    return View("Error");
                }
        }
    }
}
