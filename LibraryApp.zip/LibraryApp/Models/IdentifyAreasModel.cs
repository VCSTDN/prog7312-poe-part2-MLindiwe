﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryApp.Models
{
    public class IdentifyAreasModel
    {
        public List<QuestionViewModel> Questions { get; set; }
    }

    public class QuestionViewModel
    {
        public string Description { get; set; }
        public string[] FirstColumnItems { get; set; }
        public string[] PossibleAnswers { get; set; }
        public string Answer { get; set; }

    }

}

