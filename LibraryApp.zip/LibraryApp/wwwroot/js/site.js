﻿// Function to update the progress bar
function updateProgressBar(correctCount, totalCount) {
    const progressBar = document.getElementById("progress-bar-container");
    progressBar.innerHTML = `
        <div class="progress-bar">
            <div class="progress" style="width: ${correctCount / totalCount * 100}%"></div>
        </div>
        <div class="progress-text">Progress: ${correctCount} / ${totalCount}</div>
    `;
}

// Call this function whenever a user submits an answer
function updateProgress(correct) {
    const correctCount = parseInt('@ViewData["CorrectCount"]') || 0;
    const totalCount = parseInt('@ViewData["TotalCount"]') || 0;

    if (correct) {
        // Increment the correct count
        updateProgressBar(correctCount + 1, totalCount + 1);
    } else {
        // Just update the total count
        updateProgressBar(correctCount, totalCount + 1);
    }
}

// Call this function on page load to initialize the progress bar
window.onload = function () {
    updateProgressBar(0, 0);
};
